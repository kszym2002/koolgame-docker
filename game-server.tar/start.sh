nohup ./root/game-server -w koolshare.github.io -c /root/config.json > z.log 2>&1 &


